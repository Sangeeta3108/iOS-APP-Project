 import UIKit
 
 class MyProductViewController:UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    //MARK:- Outlets
    @IBOutlet weak var tableView: UITableView!
    var model = [MyProductDetailModelBody]()
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        model.removeAll()
        for item in Store.productsDetails!.body{
            if item.sellerName == Store.loginUser?.firstName{
                model.append(item)
            }
        }
        self.tableView.reloadData()
    }
    
    //MARK:- back button action
    @IBAction func onBackClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
     //MARK:- TableView delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyProductTableViewCell", for: indexPath) as? MyProductTableViewCell
        //  let myItem = items[indexPath.row]
        cell?.myProductName?.text = model[indexPath.row].name
        cell?.myProductPostLocation?.text = model[indexPath.row].address
        cell?.myProductPrice?.text = "$"+(model[indexPath.row].price )
        cell?.myProductImg?.image = model[indexPath.row].images[0].imageCovert
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 113.0
    }
 }
