
import UIKit

class ProductViewController:UIViewController,UITableViewDelegate,UITableViewDataSource{
 
    //MARK:- Outlets
    @IBOutlet weak var tableView: UITableView!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    } 
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tableView.reloadData()
    }
     
    //MARK:- Table View Delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Store.productsDetails?.body.count ?? 0
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "MyProductTableViewCell", for: indexPath) as? MyProductTableViewCell
      //  let myItem = items[indexPath.row]
        cell?.myProductName?.text = Store.productsDetails?.body[indexPath.row].name
        cell?.myProductPostLocation?.text = Store.productsDetails?.body[indexPath.row].address
        cell?.myProductPrice?.text = "$"+(Store.productsDetails?.body[indexPath.row].price)!
        cell?.myProductImg?.image = Store.productsDetails?.body[indexPath.row].images[0].imageCovert
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 113.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailViewController") as? ProductDetailViewController{
            vc.productModel = Store.productsDetails?.body[indexPath.row]
            vc.indexNo = indexPath.row
            self.navigationController?.pushViewController(vc, animated:true)
        }
        
    }
}
