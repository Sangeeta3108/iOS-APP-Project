 
import UIKit
class FavoriteTblCell: UITableViewCell {
    
    //MARK:- Outlets
    @IBOutlet weak var myProductImg:UIImageView!
    @IBOutlet weak var myProductName:UILabel!
    @IBOutlet weak var myProductPostLocation:UILabel!
    @IBOutlet weak var myProductPrice:UILabel!
    @IBOutlet weak var btnFavorite:UIButton!
    
    //MARK:- Button favorite action
    @IBAction func btnFavorite(_ sender: Any) {
    }
    
}
