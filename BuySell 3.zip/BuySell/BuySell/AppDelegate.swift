

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        if Store.userRegisterDetails?.body == nil{
            Store.firstTimeLogin = true
           
            
            
        }else{
          Store.firstTimeLogin = false
        }
        if Store.productsDetails == nil{
            var bodyModel = [MyProductDetailModelBody]()
            let obj = MyProductDetailModelBody(name: "Audi Car", bodyDescription: "2 year old car is looking for new owner", price: "55005.00", address: "Toronto , Ontario", sellerName: "James", sellerImage: UIImage(named: "img_uploader")!.dataConvert!, images: [UIImage(named: "audicar")!.dataConvert!,UIImage(named: "audi2")!.dataConvert!], isFav: true)
            bodyModel.append(obj)
            let obj1 = MyProductDetailModelBody(name: "Boss Speaker", bodyDescription: "Good sound like new one", price: "25.00", address: "Montreal , Quebec", sellerName: "Steve", sellerImage: UIImage(named: "img_uploader")!.dataConvert!, images: [UIImage(named: "BossSpeaker")!.dataConvert!], isFav: false)
            bodyModel.append(obj1)
            let obj2 = MyProductDetailModelBody(name: "iPhone X", bodyDescription: "No scrach on screen", price: "200.00", address: "Calgary , Alberta", sellerName: "Simon", sellerImage: UIImage(named: "img_uploader")!.dataConvert!, images: [UIImage(named: "iPhone1")!.dataConvert!,UIImage(named: "iPhone")!.dataConvert!,UIImage(named: "iPhone2")!.dataConvert!], isFav: false)
            bodyModel.append(obj2)
            let productModel = MyProductDetailModel(body: bodyModel)
            Store.productsDetails = productModel
        }
        // Override point for customization after application launch.
        return true
    }

    // MARK: UISceneSession Lifecycle

    func application(_ application: UIApplication, configurationForConnecting connectingSceneSession: UISceneSession, options: UIScene.ConnectionOptions) -> UISceneConfiguration {
        // Called when a new scene session is being created.
        // Use this method to select a configuration to create the new scene with.
        return UISceneConfiguration(name: "Default Configuration", sessionRole: connectingSceneSession.role)
    }

    func application(_ application: UIApplication, didDiscardSceneSessions sceneSessions: Set<UISceneSession>) {
        // Called when the user discards a scene session.
        // If any sessions were discarded while the application was not running, this will be called shortly after application:didFinishLaunchingWithOptions.
        // Use this method to release any resources that were specific to the discarded scenes, as they will not return.
    }


}

