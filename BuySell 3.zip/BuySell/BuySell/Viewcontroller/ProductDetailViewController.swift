 
import UIKit
import NotificationBannerSwift
import ImageSlideshow

class ProductDetailViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var slideshow:ImageSlideshow!
    @IBOutlet weak var myProductImg:UIImageView!
    @IBOutlet weak var myProductName:UILabel!
    @IBOutlet weak var myProductPrice:UILabel!
    @IBOutlet weak var myProductDescription:UILabel!
    @IBOutlet weak var sellerName:UILabel!
    @IBOutlet weak var sellerImg:UIImageView!
    @IBOutlet weak var myProductPostLocation:UILabel!
    @IBOutlet weak var btnFavorite:UIButton!
 
    //MARK:- Variables
    var productModel:MyProductDetailModelBody!
    var indexNo = 0
    var is_favourite = false
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        let gestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(self.didTap))
             slideshow.addGestureRecognizer(gestureRecognizer)
        slideshow.activityIndicator = DefaultActivityIndicator()
        slideshow.circular = true
        self.setData()
    }
    override func viewWillAppear(_ animated: Bool) {
           super.viewWillAppear(animated)
    }
    
    //MARK:- Image slider function
    @objc func didTap() {
      slideshow.presentFullScreenController(from: self)
    }
    
    //MARK:- Back button action
    @IBAction func onBackClick(){
        self.navigationController?.popViewController(animated: true)
    }
     
    //MARK:- Buy action
    @IBAction func onBuyClick(){
        Store.productsDetails?.body.remove(at: indexNo)
        let banner = NotificationBanner(title: "", subtitle: "You bought this product", style: .success)
        banner.show()
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Like button action
    @IBAction func onLikeClick(_ sender: UIButton) {
        addProductToFavorite()
    }
      
    //MARK:- Add product to favorite function
    func addProductToFavorite() {
        if is_favourite{
            is_favourite = false
            self.btnFavorite.setImage(#imageLiteral(resourceName: "heart_51"), for: .normal)
            Store.productsDetails?.body[indexNo].isFav = false
        } else {
            is_favourite = true
            self.btnFavorite.setImage(#imageLiteral(resourceName: "favourite_blue"), for: .normal)
            Store.productsDetails?.body[indexNo].isFav = true
        }
    }
     
     
    //MARK:- Product detail Function
    func productDeatil(){
//        let object = MyProductDetailViewControllerViewModel(product_id: self.productID)
//        object.myProductDetailAPI { model in
//            self.modelData = model

//            self.showMapData()
//        }
    }
    
    //MARK:- add Product to favorite
    func addProductToFavorite(product_id:String,type:String){
//        let object = HomeViewControllerViewModel()
//        object.addProductFavoriteAPI(product_id: product_id, type: type) { (model) -> (Void) in
//        }
    }
    
    //MARK:- Set data function
    func setData() {
        var arrimage = [ImageSource]()
        for imageTemp in productModel.images {
            arrimage.append(ImageSource(image: imageTemp.imageCovert!))
        }
        self.slideshow.setImageInputs(arrimage)
        self.myProductName.text! = productModel.name
        self.myProductPrice.text! = "$"+productModel.price
        self.myProductDescription.text! = productModel.bodyDescription
        self.sellerName.text! = productModel.sellerName
        self.sellerImg.image = productModel.sellerImage.imageCovert
        self.myProductPostLocation.text! = productModel.address
        if productModel.isFav{
           self.btnFavorite.setImage(#imageLiteral(resourceName: "favourite_blue"), for: .normal)
            self.is_favourite = true
        }else{
           self.btnFavorite.setImage(#imageLiteral(resourceName: "heart_51"), for: .normal)
            self.is_favourite = false
        }
    }
}
