 
import UIKit
import NotificationBannerSwift

class RegisterViewController: UIViewController,UINavigationControllerDelegate, UITextFieldDelegate {
    
    //MARK:- Outlets
    @IBOutlet weak var cameraBtn:UIButton!
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var emailTF: UITextField!
    @IBOutlet weak var nameTF: UITextField!
    @IBOutlet weak var passwordTF: UITextField!
    @IBOutlet weak var confirmPasswordTF: UITextField!
    
    //MARK:- Variables
    var STRING_EMPTY = ""
    var imageSelected = false
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        nameTF.delegate = self
        emailTF.delegate = self
     }
    override func viewDidLayoutSubviews() {
        imgProfile.layer.cornerRadius = imgProfile.frame.size.width / 2
        imgProfile.layer.masksToBounds = true
        imgProfile.clipsToBounds = true
        imgProfile.contentMode = .scaleAspectFill
        self.view.layoutIfNeeded()
    }
    
    //MARK:- Back button action
    @IBAction func onBackClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Register action
    @IBAction func onRegisterClick(){
        let validation = self._validationData()
        if validation!.count != 0 {
            let banner = NotificationBanner(title: "Error", subtitle: validation, style: .danger)
            banner.show()
            return
        }
        if Store.firstTimeLogin{
            var body = [LoginSignUpModelBody]()
            let data = LoginSignUpModelBody(id: emailTF.text!+passwordTF.text!, firstName: nameTF.text!, email: emailTF.text!, password: passwordTF.text!, image: imgProfile.image!.dataConvert!)
            body.append(data)
            let obj = LoginSignUpModel(body: body)
            Store.loginUser = data
            Store.userRegisterDetails = obj
        }else{
            let data = LoginSignUpModelBody(id: emailTF.text!+passwordTF.text!, firstName: nameTF.text!, email: emailTF.text!, password: passwordTF.text!, image: imgProfile.image!.dataConvert!)
            Store.loginUser = data
            Store.userRegisterDetails?.body.append(data)
        }
        self.pushHomeVC()
    }
    
    //MARK:- Push Home View controller function
    func pushHomeVC() {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController{
            let nvc = UINavigationController(rootViewController: vc)
            nvc.modalPresentationStyle = .overFullScreen
            self.present(nvc, animated: true, completion: nil)
        }
       // self.navigationController?.popViewControllers(viewsToPop: 2)
    }
    
    //MARK:- Login action
    @IBAction func onLoginClick(){
      
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Camera action
    @IBAction func onCameraClick(_ sender:UIButton){
        ImagePickerManager().pickImage(self) { (image) in
            self.imgProfile.image = image
            self.cameraBtn.setImage(UIImage(named: ""), for: .normal)
            let validation = self._validateDisplayImage()!
            if validation.count != 0 {
                let alert = UIAlertController(title: "", message: validation, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: { acttion in
                }))
                self.present(alert, animated: true) {
                }
                return
            }
            else {
                self.imageSelected = true
            }
        }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK:- Validate Image Function
    func _validateDisplayImage() -> String?{
        var validString = ""
        if (imgProfile.image == nil) {
            validString += "Please select image"
        }
        return validString
    }
     
    //MARK:- Customer Validation
    func _validationData() -> String? {
        var validString = STRING_EMPTY
        
        if (imageSelected == false) {
            return  "Please choose image.\n"
        }
        let firstName = nameTF.text //First Name
        if (firstName == STRING_EMPTY) {
            return "Please enter name.\n"
        }
        let email = emailTF.text //email
        if (email == STRING_EMPTY) {
            return  "Please enter email.\n"
        } else {
            if !email!.isValidEmail() {
                return  "Invalid email.\n"
            }
        }
        let password = passwordTF.text //password
        if (password == STRING_EMPTY) {
            return  "Please enter password.\n"
        } else {
            if password!.count < 6 {
                return  "Password must have minimum 6.\n"
            }
            if password!.count > 12 {
                return  "Password must have minimum 10.\n"
            }
        }
        let confirmPassword = confirmPasswordTF.text //password
        if (confirmPassword == STRING_EMPTY) {
            return  "Please enter confirm password.\n"
        } else {
            if password != confirmPassword {
                return  "Password and confirm password must be same.\n"
            }
        }
        return validString
    }

}
 
extension String {
    func isValidEmail() -> Bool {
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailTest = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        return emailTest.evaluate(with: self)
    }
}


