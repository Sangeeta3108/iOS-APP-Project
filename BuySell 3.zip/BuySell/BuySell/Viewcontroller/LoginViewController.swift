import UIKit
import NotificationBannerSwift
import IQKeyboardManager

class LoginViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var emaiL_TF: UITextField!
    @IBOutlet weak var password_TF: UITextField!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    //MARK:- Login action
    @IBAction func onLoginClick(){
        let validation = self._validationData()
        if validation!.count != 0 {
            let banner = NotificationBanner(title: "Error", subtitle: validation, style: .danger)
            banner.show()
            return
        }
        let data = Store.userRegisterDetails?.body.filter{
            if $0.email+$0.password == emaiL_TF.text!+password_TF.text!{
                Store.loginUser = $0
                return true
            }else{
                return false
            }
        }
        if data != nil{
           self.pushVc()
        }else{
            let banner = NotificationBanner(title: "Error", subtitle: "Email does not exist", style: .danger)
            banner.show()
            return
        }
    }
    
    //MARK:- Rgister action
    @IBAction func onRegisterClick(){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "RegisterViewController") as? RegisterViewController{
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    //MARK:- Forgot Password action
    @IBAction func onFogotClick(){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ForgotPasswordViewController") as? ForgotPasswordViewController{
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    //MARK:- Push Home View controller function
    func pushVc(){
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "TabBarViewController") as? TabBarViewController{
            let nvc = UINavigationController(rootViewController: vc)
            nvc.modalPresentationStyle = .overFullScreen
            self.present(nvc, animated: true, completion: nil)
        }
    }
    
    //MARK:- Customer Validation
    func _validationData() -> String? {
        let validString = ""
        let email = emaiL_TF.text //Mobile
        if (email == "") {
            return  "Please enter email.\n"
        }
        let password = password_TF.text //Mobile
        if (password == "") {
            return "Please enter password.\n"
        }
        return validString
    }
}
