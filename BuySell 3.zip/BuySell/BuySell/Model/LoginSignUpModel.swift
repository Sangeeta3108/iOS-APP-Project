
import Foundation
import UIKit
// MARK: - LoginSignUpModel
struct LoginSignUpModel: Codable {
    var body: [LoginSignUpModelBody]
}

// MARK: - Body
struct LoginSignUpModelBody: Codable {
    var id, firstName: String
    var email, password: String
    var image: Data
    enum CodingKeys: String, CodingKey {
        case id
        case image
        case firstName = "first_name"
        case email, password
    }
}
extension UIImage {
    var dataConvert: Data? {
        if let data = self.jpegData(compressionQuality: 1.0) {
            return data
        } else {
            return nil
        }
    }
}

extension Data {
    var imageCovert: UIImage? {
        if let image = UIImage(data: self) {
            return image
        } else {
            return nil
        }
    }
}

