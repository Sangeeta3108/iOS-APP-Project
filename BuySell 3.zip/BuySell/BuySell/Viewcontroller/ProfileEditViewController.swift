 
import UIKit
import IQKeyboardManager
import NotificationBannerSwift

class ProfileEditViewController: UIViewController,UINavigationControllerDelegate {
    
    //MARK:- Outlets
    @IBOutlet weak var imgProfile:UIImageView!
    @IBOutlet weak var nameTF:UITextField!
    @IBOutlet weak var emailTF:UITextField!
    
   //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        emailTF.isUserInteractionEnabled = false
        self.nameTF.text = Store.loginUser?.firstName
        self.emailTF.text = Store.loginUser?.email
        self.imgProfile.image = Store.loginUser?.image.imageCovert
    }
    
    //MARK:- back button action
    @IBAction func onBackClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- update button action
    @IBAction func onUpdateClick(){
        Store.loginUser?.firstName = self.nameTF.text!
        Store.loginUser?.email = self.emailTF.text!
        Store.loginUser?.image = self.imgProfile.image!.dataConvert!
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- camera click button action
    @IBAction func onCameraClick(_ sender:UIButton){
        ImagePickerManager().pickImage(self) { (image) in
             self.imgProfile.image = image
         }
    }
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK:- update profile message function  
    func updateProfilePOPUP() {
        let banner = NotificationBanner(title: "", subtitle: "Profile updated successfully", style: .success)
        banner.show()
    }
      
}
