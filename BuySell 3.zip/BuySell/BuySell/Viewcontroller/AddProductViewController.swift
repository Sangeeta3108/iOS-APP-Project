 
import UIKit
import NotificationBannerSwift

class AddProductViewController: UIViewController,UITextViewDelegate{
    
    //MARK:- Outlets
    @IBOutlet weak var tfTitle:UITextField!
    @IBOutlet weak var tfLocation:UITextField!
    @IBOutlet weak var tfPrice:UITextField!
    @IBOutlet weak var tfDescription:UITextView!
    @IBOutlet weak var lblTitle:UILabel!
    @IBOutlet weak var btnSubmit:UIButton!
    @IBOutlet var imgCollection:[UIImageView]!
    
    //MARK:- Variables
    var imagesCover = [UIImage]()
    var selectedImgBool = [false,false,false,false,false]
 
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
     }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tfDescription.text = "Description"
        tfDescription.textColor = UIColor.lightGray
        emptyAllFeild()
    }
    //MARK:- Submit button action
    @IBAction func onSubmitClick(){
        addProductFunc()
    } 
    
     //MARK:- Image pick action
    @IBAction func onImgClick(_ sender:UIButton){
        ImagePickerManager().pickImage(self) { (image) in
            let indexTag = sender.tag - 101
            self.imgCollection[indexTag].image = image
            self.selectedImgBool[indexTag] = true
        }
    }
     
    //MARK:- empty all textfeilds function
    func emptyAllFeild() {
        tfTitle.text = ""
        tfLocation.text = ""
        tfPrice.text = ""
        tfDescription.text = ""
        imagesCover.removeAll()
        selectedImgBool = [false,false,false,false,false]
        for item in imgCollection{
            item.image = nil
        }
    }
    
    //MARK:- Add product funtion
    func addProductFunc() {
        let validation = self._validationData()
        if validation!.count != 0 {
            let banner = NotificationBanner(title: "Error", subtitle: validation, style: .danger)
            banner.show()
            return
        }
        for bol in selectedImgBool.indices{
            if selectedImgBool[bol]{
                self.imagesCover.append(imgCollection[bol].image!)
            }
        }
        var imgArrData = [Data]()
        for item in self.imagesCover{
            imgArrData.append(item.dataConvert!)
        }
        let obj = MyProductDetailModelBody(name: tfTitle.text!, bodyDescription: tfDescription.text!, price: tfPrice.text!, address: tfLocation.text!, sellerName: Store.loginUser!.firstName, sellerImage: Store.loginUser!.image, images: imgArrData, isFav: false)
        Store.productsDetails?.body.append(obj)
        self.productApprovalMessage()
    }
    
    //MARK:- product approval message function
    func productApprovalMessage() {
        let banner = NotificationBanner(title: "", subtitle: "Product Added Successfully.", style: .success)
        banner.show()
        emptyAllFeild()
    }
    
    //MARK:- Text view delegate methods
    func textViewDidBeginEditing(_ textView: UITextView) {
        if textView.textColor == UIColor.lightGray {
            textView.text = nil
            textView.textColor = UIColor.black
        }
    }
    func textViewDidEndEditing(_ textView: UITextView) {
        if textView.text.isEmpty {
            textView.text = "Description"
            textView.textColor = UIColor.lightGray
        }
    }
    var STRING_EMPTY = ""
    //MARK:- Customer Validation
    func _validationData() -> String? {
        var validString = STRING_EMPTY
        var selBool = false
        for item in selectedImgBool{
            if item{
                selBool = true
            }
        }
        if (selBool == false) {
            return  "Please choose image.\n"
        }
        let title = tfTitle.text
        if (title == STRING_EMPTY) {
            return "Please enter Title.\n"
        }
        let location = tfLocation.text
        if (location == STRING_EMPTY) {
            return  "Please select location.\n"
        }
        let price = tfPrice.text
        if (price == STRING_EMPTY) {
            return  "Please enter price.\n"
        }
        let description = tfDescription.text
        if (description == STRING_EMPTY) {
            return "Please enter description.\n"
        }
        return validString
    }
}
