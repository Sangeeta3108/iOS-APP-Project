import UIKit
import NotificationBannerSwift
class ChangePasswordVC: UIViewController {
 
    //MARK:- Outlets
    @IBOutlet weak var tf_OldPswd: UITextField!
    @IBOutlet weak var tf_NewPswd: UITextField!
    @IBOutlet weak var tf_ConfirmPswd: UITextField!
    
    var STRING_EMPTY = ""
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
     }
    
     //MARK:- update password button action
    @IBAction func updatePasswordBtnAction(_ sender: Any) {
        let validation = self._validationData()
        if validation!.count != 0 {
            let banner = NotificationBanner(title: "Error", subtitle: validation, style: .danger)
            banner.show()
            return
        }
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- back button action
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    
    //MARK:- Customer Validation
           func _validationData() -> String? {
               var validString = STRING_EMPTY
               
               let firstPswd = tf_OldPswd.text //First Name
               if (firstPswd == STRING_EMPTY) {
                   return "Please enter password\n"
               }
               let newPswd = tf_NewPswd.text //email
               if (newPswd == STRING_EMPTY) {
                   return  "Please enter new password.\n"
               }
               let confirmPswd = tf_ConfirmPswd.text //Mobile
               if (confirmPswd == STRING_EMPTY) {
                   return  "Please enter confirm password.\n"
               }
               if !(tf_NewPswd.text == STRING_EMPTY) && !(tf_ConfirmPswd.text == STRING_EMPTY) {
                   if !(tf_NewPswd.text == tf_ConfirmPswd.text) {
                       return "Password doesn't match"
                   }
               }
               return validString
           }
       
}
