 

import UIKit
import NotificationBannerSwift

class ForgotPasswordViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var emaiL_TF:UITextField!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    //MARK:- Back button action
    @IBAction func onBackClick(){
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- Submit action
    @IBAction func onSubmitClick(){
        let validation = self._validationData()
        if validation!.count != 0 {
            let banner = NotificationBanner(title: "Error", subtitle: validation, style: .danger)
            banner.show()
            return
        }
        self.navigationController?.popViewController(animated: true)
        
    }
    
    //MARK:- Customer Validation
    func _validationData() -> String? {
        let validString = ""
        let email = emaiL_TF.text //Mobile
        if (email == "") {
            return  "Please enter email.\n"
        }
        return validString
    }
}
