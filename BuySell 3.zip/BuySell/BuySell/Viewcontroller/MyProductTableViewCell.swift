
import UIKit

class MyProductTableViewCell: UITableViewCell {
    
    //MARK:- Outlets
    @IBOutlet weak var myProductImg:UIImageView!
    @IBOutlet weak var myProductName:UILabel!
    @IBOutlet weak var myProductPostLocation:UILabel!
    @IBOutlet weak var myProductPrice:UILabel!
}


