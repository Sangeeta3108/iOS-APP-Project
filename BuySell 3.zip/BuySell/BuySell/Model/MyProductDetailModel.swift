
import Foundation

// MARK: - MyProductDetailModel
struct MyProductDetailModel: Codable {
    var body: [MyProductDetailModelBody]
}
// MARK: - Body
struct MyProductDetailModelBody: Codable {
    let name, bodyDescription: String
    let price: String
    let address: String
    let sellerName: String
    let sellerImage: Data
    let images: [Data]
    var isFav:Bool
    enum CodingKeys: String, CodingKey {
        case name
        case bodyDescription = "description"
        case price
        case address
        case sellerName = "seller_name"
        case sellerImage = "seller_image"
        case images
        case isFav
    }
}

