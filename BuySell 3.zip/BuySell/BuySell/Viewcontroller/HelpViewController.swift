 
import UIKit

class HelpViewController: UIViewController {
    
    //MARK:- Outlets
    @IBOutlet weak var descriptionLbl:UILabel!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setData()
    }
    
    //MARK:- back button action
    @IBAction func onBackClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
    //MARK:- set data function
    func setData(){
        self.descriptionLbl.text = "We validate the accounts of BUYSELL users by using SMS verification to ensure that each account is associated with a real and unique user. This validation process is initiated once you proceed to posting your first ad listing on our Services. In order to validate your BUYSELL account before posting your ad listing we will send you an SMS on a valid mobile number provided by  you. This process is entirely free of charge.\nIf you do not agree to validate your account, then your account will remain active and you will be able to use our Services with limited functionality. This limited functionality of an account implies that you can not publish new ad listings or edit, update, promote, extend, reactivate, deactivate or delete existing ad listings until your account is verified by SMS. You will also not be able to receive or reply to any messages from other users.\nIn case you create several BUYSELL accounts using the same mobile number and validate all those accounts via SMS verification, all such accounts will have a limited functionality and you will be asked to choose one of them. The account chosen by you will return to full functionality, and the rest of the accounts will remain to have  limited functionality.\nEvery user can request a maximum of 5 SMS messages with verification codes, within 24 hours. Account validation is done only once for each account, until it is successfully verified via SMS by the user.\nOnce you have validated your BUYSELL account, it will remain associated with the mobile number used for the SMS verification. If you wish to change the mobile number associated with your BUYSELL account, you will need to contact our Customer Support team."
        self.descriptionLbl.isUserInteractionEnabled = true
        self.descriptionLbl.font = UIFont.systemFont(ofSize: 14)
    }
}
