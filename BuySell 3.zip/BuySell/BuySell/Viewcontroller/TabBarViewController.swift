 
import UIKit

class TabBarViewController: UITabBarController {

    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        self.navigationController?.isNavigationBarHidden = true
     }
}
