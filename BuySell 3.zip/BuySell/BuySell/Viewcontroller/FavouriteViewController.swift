 
 import UIKit
 
 class FavouriteViewController:UIViewController,UITableViewDelegate,UITableViewDataSource{
    
    //MARK:- Outlets
    @IBOutlet weak var tableView: UITableView!
    var model = [MyProductDetailModelBody]()
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        model.removeAll()
        for item in Store.productsDetails!.body{
            if item.isFav == true{
                model.append(item)
            }
        }
        self.tableView.reloadData()
    }
    //MARK:- Table View Delegate methods
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.count 
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "FavoriteTblCell", for: indexPath) as? FavoriteTblCell
        cell?.myProductName?.text = model[indexPath.row].name
        cell?.myProductPostLocation?.text = model[indexPath.row].address
        cell?.myProductPrice?.text = "$"+(model[indexPath.row].price )
        cell?.myProductImg?.image = model[indexPath.row].images[0].imageCovert
        return cell!
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 113.0
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
//        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProductDetailViewController") as? ProductDetailViewController{
//            vc.productID = modelDataRequestJob.body[indexPath.row].id
//            self.navigationController?.pushViewController(vc, animated:true)
//        }
        
    }
 }
