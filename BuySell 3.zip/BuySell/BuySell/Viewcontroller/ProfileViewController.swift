 
import UIKit
import NotificationBannerSwift
class ProfileViewController: UIViewController {

    //MARK:- Outlets
    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var userName: UILabel!
    
    //MARK:- View life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(true)
        self.userName.text = Store.loginUser?.firstName
        self.imgProfile.image = Store.loginUser?.image.imageCovert
    }
     
    //MARK:- edit button action
    @IBAction func onViewEditClick(_ sender: UIButton) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileEditViewController") as? ProfileEditViewController{
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
     
    //MARK:- my products action
    @IBAction func onMyProductsClick(_ sender: Any) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "MyProductViewController") as? MyProductViewController {
            self.navigationController?.pushViewController(vc, animated:true)
        }

    }
    
    //MARK:- Change password button action
    @IBAction func onChangePasswordClick(_ sender: Any) {
                 if let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChangePasswordVC") as? ChangePasswordVC{
             self.navigationController?.pushViewController(vc, animated:true)
         }
    }
    
    //MARK:- help button action
    @IBAction func onHelpClick(_ sender: Any) {
        if let vc = self.storyboard?.instantiateViewController(withIdentifier: "HelpViewController") as? HelpViewController{
            self.navigationController?.pushViewController(vc, animated:true)
        }
    }
    
    //MARK:- log out button action
    @IBAction func onLogoutClick(_ sender: Any) {
        let confirmAlertCtrl = UIAlertController(title: NSLocalizedString("BuySell", comment: "Logout"), message: NSLocalizedString("Are you sure you want to be logout", comment: "Are you sure you want to be logout"), preferredStyle: .alert)
        
        let confirmAction = UIAlertAction(title: "Logout", style: .destructive) { _ in
            self.dismiss(animated: true, completion: nil)
            self.logout()
        }
        confirmAlertCtrl.addAction(confirmAction)
        
        let cancelAction = UIAlertAction(title: NSLocalizedString("Cancel", comment: "Cancel"), style: .cancel, handler: nil)
        confirmAlertCtrl.addAction(cancelAction)
        
        self.present(confirmAlertCtrl, animated: true, completion: nil)
    }
    
    //MARK:- log out function
    func logout(){
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
        let nav = UINavigationController()
        nav.pushViewController(vc, animated: true)
        self.view.window?.rootViewController = nav
    }
}
 
